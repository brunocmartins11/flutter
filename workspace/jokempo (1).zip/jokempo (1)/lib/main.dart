import 'package:flutter/material.dart';
import 'package:jokempo/telas/jogo.dart';

void main() {
  runApp(MaterialApp(
    home: Jogo(),
    debugShowCheckedModeBanner: false,
  ));
}
