package com.example.jokempo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
